<?php
// place for helper functions like be_icon() or helpers
