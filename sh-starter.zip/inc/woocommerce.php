<?php
// Minimal WooCommerce tweaks
add_filter('woocommerce_enqueue_styles', '__return_empty_array');
