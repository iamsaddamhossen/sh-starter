<?php
// SH Starter - Theme loader
require get_template_directory() . '/inc/setup.php';
require get_template_directory() . '/inc/enqueue.php';
require get_template_directory() . '/inc/blocks.php';
require get_template_directory() . '/inc/block-areas.php';
require get_template_directory() . '/inc/woocommerce.php';
require get_template_directory() . '/inc/login-logo.php';
require get_template_directory() . '/inc/custom-functions.php';
